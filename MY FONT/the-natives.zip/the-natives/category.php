<?php
get_header();
$cat = get_queried_object();
?>

    <div class="blog_page">
    </div>

<?php get_footer();